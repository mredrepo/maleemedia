import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import xbmc, sys
xbmc.log(repr(sys.argv))




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.coreelecfirmware'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.coreelecfirmware'
AddonTitle="CoreELEC Firmware Updater"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
PATH = "Firmware Updater"
addon= xbmcaddon.Addon()
path = addon.getAddonInfo('path').decode("utf-8") + "/icon.png"            
BASEURL = "Firmware Updater"
# JARVIS 2 gb box
BASEURL1 = "https://archive.org/download/cefirmware/" 
# JARVIS 1 gb box
BASEURL2 = "https://archive.org/download/cefirmware/"
# KRYPTON 2 gb box
BASEURL3 = "https://archive.org/download/cefirmware/"
# KRYPTON 1gb box
BASEURL4 = "https://archive.org/download/cefirmware/"
H = 'http://'
EXCLUDES     = ['service.CoreELEC.settings','script.module.addon.common','repository.maleemedia','plugin.program.lebuildrestore','plugin.program.coreelecfirmware','plugin.program.kryptonupdaterCoreELEC','.storage/config']

	
	#elif mode==4
def INDEX():#KRYPTON(): KRYPTON ONLY OPTION RIGHT NOW
	addDir('PICK BOX',BASEURL,4,ART+'pickyourbox.png',FANART,'') #4
	addDir('TX7',BASEURL3+'/krypton2_gb.zip',2,ART+'tx7.png',FANART,'')
	addDir('BEELINK',BASEURL3+'/krypton2_gb.zip',2,ART+'beelink.png',FANART,'')
	addDir('MXQ S905X',BASEURL3+'/krypton1_gb.zip',2,ART+'mxqs905x.png',FANART,'')
	addDir('TX9 PRO',BASEURL3+'/krypton2_gb.zip',2,ART+'tx9.png',FANART,'')
	#addDir('MXQ S805',BASEURL4+'/kryptons805.zip',2,ART+'mxqs805.png',FANART,'')
	setView('movies', 'MAIN')

	
#################################
####FIRMWARE UPGRADE AND DOWNGRADE################
#################################

def UPDATER(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("FIRMWARE UPDATER","DOWNLOADING THE ZIP ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = (os.path.join('storage','.update'))
    #addonfolder = (os.path.join('I:','S905X'))
    time.sleep(5)
    dp.update(0,"", "EXTRACTING THE FIRMWARE")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("FIRMWARE UPDATER", "PRESS [B]OK[/B] TO ENABLE A REBOOT",'', '[COLOR red][B]!!!WARNING!!![/B][/COLOR] DO NOT POWER OFF BOX WHEN UPGRADE IS IN PROGRESS')
    time.sleep(2)	
    xbmc.executebuiltin('Reboot')

############################
###FRESH START##############
####THANKS TO TVADDONS######

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"[COLOR red][B]!!!WARNING!!![/B][/COLOR] ONLY CLICK YES IF YOU ARE ON KODI 16 JARVIS THIS WILL WIPE EVERYTHING")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0;
        DP.create(AddonTitle,"Clearing all files and folders:",'', '')
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    del_file += 1
                    DP.update(int(percentage(del_file, total_files)), '', 'File: [color=#000000]%s[/color]' % name, '')
					#ADD ANY FILES YOU DONT WANT DELETED HERE
                    if name in ['Addons27.db', 'kodi.log']: plugintools.log("Keep Log File: %s" % name)
                    else:
                        try: os.remove(os.path.join(root,name))
                        except:
                            if name not in ["Addons20.db","MyVideos99.db","Textures13.db","MyVideos107.db"]: failed=True
                            plugintools.log("Error removing "+root+" "+name)
                       
            for root, dirs, files in os.walk(xbmcPath,topdown=True):           
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in dirs:
                    DP.update(100, '', 'Cleaning Up Empty Folder: [color=#000000]%s[/color]' % name, '')
                    if name not in ["Database","userdata","temp","addons","addon_data"]:
                        shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)

            DP.close()
            if not failed: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot click PROGRAMS and re-launch [COLOR lime][B]CoreELEC Firmware Updater[/B][/COLOR],16500, %s)' % (path))
            else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot click PROGRAMS and re-launch [COLOR lime][B]CoreELEC Firmware Updater[/B][/COLOR],16500, %s)' % (path))
        except: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    xbmc.sleep(16500)	
    xbmc.executebuiltin('Reboot')
    #xbmc.executebuiltin('ActivateWindow(Home)')
    
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()
		
elif mode==2:
        UPDATER(name,url,description)
		
elif mode==5:        
	FRESHSTART(params)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
