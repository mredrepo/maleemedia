# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import xbmc, sys
xbmc.log(repr(sys.argv))




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.adultaddons'
ADDON = xbmcaddon.Addon(id=addon_id)
addon= xbmcaddon.Addon()
path = addon.getAddonInfo('path').decode("utf-8") + "/icon.png"
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.adultaddons'
AddonTitle="Adult Extras"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Adult Extras"            
BASEURL = "https://archive.org/download/maleeadult"
BASEURL1 = "https://archive.org/download/maleeadult"
H = 'http://'

def INDEX():
	addDir('PASSWORD',BASEURL+'/adult.zip',2,ART+'password.png',FANART,'')
	addDir('NO PASSWORD',BASEURL1+'/nopassword.zip',2,ART+'nopassword.png',FANART,'')
	addDir('DELETE ADULT',BASEURL,3,ART+'delete.png',FANART,'')
	setView('movies', 'MAIN')

#################################
####### POPUP TEXT BOXES ########
#################################

def TextBoxes(heading,announce):
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(announce); text=f.read()
      except: text=announce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()

#######################################UPDATE BUILD 5 ##############################

def WIZARD(name,url,description):
    xbmc.executebuiltin('ActivateWindow(Home)')
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dialog = xbmcgui.Dialog()
    dialog.ok("ADULT EXTRAS", "PRESS [B]OK[/B] TO INSTALL THE ADULT EXTRAS")
    dp = xbmcgui.DialogProgress()
    dp.create("ADULT EXTRAS","DOWNLOADING THE ADDONS ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE ADDONS")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("ADULT EXTRAS", "THE ADULT EXTRAS ARE NOW INSTALLED. [COLOR red][B]  ACCESS CODE IS 1111 IF ENABLED [/B][/COLOR]")
    time.sleep(2)
    enableaddons()

	
def delete():
	#####################################################  ADDONS  ##################################
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.XXXXXXXXX/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.youporn/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.videodevil/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.empflix/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.erotik/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.fantasticc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.lubetube/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.xxx-o-dus/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/repository.xbmcadult/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/repository.xxxadultxbmc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/repository.xxxecho/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/plugin.video.uwc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/addons/repository.whitecream/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	#####################################################  ADDON DATA  ##############################
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.XXXXXXX/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.youporn/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.videodevil/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.empflix/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.erotik/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)


	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.fantasticc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.lubetube/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.xxx-o-dus/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.video.uwc/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/plugin.program.super.favourites/Super Favourites/ADULT/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)

	
	TARGETFOLDER = xbmc.translatePath( 
		'special://home/userdata/addon_data/script.pinsentry/'
		)

	def remove_dir (path):
		if os.path.exists(path) :
			dflist = os.listdir(path)
			for itm in dflist:
				_path = os.path.join(path, itm)
				if os.path.isfile(_path):
						os.remove(_path)
				else:
						remove_dir(_path)
			os.rmdir(path)

	remove_dir(TARGETFOLDER)
	########################################### ACTIVATE WINDOW HOME  ##############################
	xbmc.executebuiltin('Reboot')
	#################################
####ENABLE ADDONS KRYPTON########
#################################
	
#Makes log easier to follow:
def printstar():
	print "[COLOR white]***************************************************************************************"
	print "[COLOR white]***************************************************************************************"

	
def enableaddons():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")

	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmcgui.Dialog().ok('Some addons were not enabled.', 'Check your log for details.')
	xbmc.sleep(200)
	#FOR UNIVERSAL BUILD NO REBOOT
	#xbmc.executebuiltin('ActivateWindow(Home)')
	#FOR LibreELEC AND EmbER BUILDS REBOOT COMMAND
	xbmc.executebuiltin(' Notification(ADULT BUILD INSTALLED,Kodi will now reboot,3000, %s)' % (path))
	xbmc.sleep(2500)
	xbmc.executebuiltin('Reboot')

	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
	
	        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def percentage(part, whole):
    return 100 * float(part)/float(whole)

	        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')


def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()
		
elif mode==2:
        WIZARD(name,url,description)
  
elif mode==3:
        delete()
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
