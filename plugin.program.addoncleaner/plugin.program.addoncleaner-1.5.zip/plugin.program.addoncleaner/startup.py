######################################################################################################################################################
##
## STARTUP SERVICE
##
######################################################################################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import time
import urllib2,urllib
import re
import uservar
from datetime import date, datetime, timedelta
from resources.libs import wizard as wiz


AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')

if AUTOCLEANUP == 'true':
	if AUTOCACHE == 'true': wiz.log('[AUTO CLEAN UP][Cache: on]'); wiz.clearCache()
	else: wiz.log('[AUTO CLEAN UP][Cache: off]')
	if AUTOPACKAGES == 'true': wiz.log('[AUTO CLEAN UP][Packages: on]'); wiz.clearPackages('startup')
	else: wiz.log('[AUTO CLEAN UP][Packages: off]')
else: wiz.log('[AUTO CLEAN UP: off]')

######################################### COPY SECTION BELOW PER ADDON ##################################

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.XXXXXXXXX/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.XXXXXXX/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

################################################# COPY SECTION ABOVE PER ADDON  ##############################

############################################### PASTE NEW SECTIONS HERE THEN EDIT  ##############################

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.bennu/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.bennu/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.strictlyhd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.strictlyhd/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.duckpool/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.mdrepo/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.kodil/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.podgod/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.dandymedia/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.aresproject/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.colossus/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.eldorado/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.lucifer/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.smash/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.metalkettle/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.program.kryptonupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.program.kryptonupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.program.jarvisupdaterfresh/' 
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.program.jarvisupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.expattv/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.expattv/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.MikeysKaraoke/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.MikeysKaraoke/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.XXXXXXXXX/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.navi-x/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.navi-x/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.concertarchive/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.concertarchive/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.XXXXXXX/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.exodus/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.istream/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


########################################### ACTIVATE WINDOW HOME  ##############################
#xbmc.executebuiltin('ActivateWindow(Home)')
xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")

