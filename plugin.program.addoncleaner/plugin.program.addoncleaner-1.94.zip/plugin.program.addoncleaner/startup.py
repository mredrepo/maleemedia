######################################################################################################################################################
##
## STARTUP SERVICE
##
######################################################################################################################################################

import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob
import shutil
import time
import urllib2,urllib
import re
import uservar
from datetime import date, datetime, timedelta
from resources.libs import wizard as wiz


AUTOCLEANUP    = wiz.getS('autoclean')
AUTOCACHE      = wiz.getS('clearcache')
AUTOPACKAGES   = wiz.getS('clearpackages')

if AUTOCLEANUP == 'true':
	if AUTOCACHE == 'true': wiz.log('[AUTO CLEAN UP][Cache: on]'); wiz.clearCache()
	else: wiz.log('[AUTO CLEAN UP][Cache: off]')
	if AUTOPACKAGES == 'true': wiz.log('[AUTO CLEAN UP][Packages: on]'); wiz.clearPackages('startup')
	else: wiz.log('[AUTO CLEAN UP][Packages: off]')
else: wiz.log('[AUTO CLEAN UP: off]')

######################################### COPY SECTION BELOW PER ADDON ##################################

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.XXXXXXXXX/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.XXXXXXX/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

################################################# COPY SECTION ABOVE PER ADDON  ##############################

############################################### PASTE NEW SECTIONS HERE THEN EDIT  ##############################

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.bennu/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.bennu/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.strictlyhd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.strictlyhd/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.duckpool/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.mdrepo/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.kodil/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.podgod/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.dandymedia/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.aresproject/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.colossus/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.eldorado/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.lucifer/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.smash/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.metalkettle/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.program.kryptonupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.program.kryptonupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.program.jarvisupdaterfresh/' 
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.program.jarvisupdaterfresh/'  
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.expattv/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.expattv/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.MikeysKaraoke/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.MikeysKaraoke/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.navi-x/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.navi-x/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.concertarchive/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.concertarchive/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.exodus/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.istream/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/superrepo.kodi.krypton.all/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/superrepo.kodi.jarvis.all/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.playonmonkey/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.whitecream/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.Kinkin/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)



TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.SpinzTV/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.spinzstrictlyhd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.spinzstrictlyhd/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.world.news.live/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.world.news.live/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.icefilms/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.icefilms/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.icechannel/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.dialogs/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.about.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.internetconnection.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.lists.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.movies.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.icechannel.DUCKPOOL.movies.settings/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.tv_shows.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.icechannel.DUCKPOOL.tv_shows.settings/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.DUCKPOOL.xbmcintegration.settings/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.icechannel.DUCKPOOL.xbmcintegration.settings/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.extn.common/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.icechannel.theme.default/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.salts/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.salts/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.salts/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.mobdina/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.mobdina/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.themusicsource/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.themusicsource/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.bob.unleashed/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.bob.unleashed/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.covenant/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.covenant/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.disneyjunior/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.disneyjunior/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.ukmvjb/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.ukmvjb/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.veetle/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.veetle/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.cartoons8/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.cartoons8/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.md123movies/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.md123movies/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.F.T.V/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.F.T.V/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.cardinal/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.Firestickplusman/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.gracie242/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.HalowTV/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.lookingglass/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.noobsandnerds/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.sweetwork/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.thebeautifulgame/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.thebeautifulgame/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.audio.xbmchubmusic/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.audio.xbmchubmusic/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.fishermanscove/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.fishermanscove/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.knockout/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.knockout/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.ntv/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.ntv/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.picasso/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.picasso/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.TheJukeBox/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.TheJukeBox/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.Goliath/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.zt/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.blamo/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.elysium/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.elysium/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.elysium/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.audio.jango/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.audio.jango/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.football.today/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.football.today/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.underdog/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.underdog/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.underdogscrapers/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.module.underdogscrapers/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.nanscrapers/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.module.nanscrapers/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.mrknow.urlresolver/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.mrknow.urlresolver/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.dudehere.routines/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/script.module.dudehere.routines/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.motorreplays/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.superreplays/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.illuminati/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.covenant.artwork/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.covenant.metadata/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.elysium.artwork/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.axel.downloader/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.covenant/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.muckys.common/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/script.module.tknorris.shared/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.alive.hd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.bbciplayer/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.bbciplayer/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.beats.hd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.documented.hd/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.itv/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.itv/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.sli/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.sli/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.specto/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.specto/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.tvcatchup.unrestricted/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.tvcatchup.unrestricted/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/plugin.video.tvcatchups/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


TARGETFOLDER = xbmc.translatePath( 
    'special://home/userdata/addon_data/plugin.video.tvcatchups/'  ### INPUT NAME OF ADDON DATA TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)

TARGETFOLDER = xbmc.translatePath( 
    'special://home/addons/repository.filmkodi.com/'  ### INPUT NAME OF ADDON TO DELETE HERE #######
    )

def remove_dir (path):
	if os.path.exists(path) :
		dflist = os.listdir(path)
		for itm in dflist:
			_path = os.path.join(path, itm)
			if os.path.isfile(_path):
					os.remove(_path)
			else:
					remove_dir(_path)
		os.rmdir(path)

remove_dir(TARGETFOLDER)


########################################### ACTIVATE WINDOW HOME  ##############################
#xbmc.executebuiltin('ActivateWindow(Home)')
xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")

