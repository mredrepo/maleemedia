#!/bin/sh
systemctl restart kodi