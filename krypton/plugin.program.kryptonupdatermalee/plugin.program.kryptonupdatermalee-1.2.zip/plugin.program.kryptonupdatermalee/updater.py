# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
import plugintools
from addon.common.addon import Addon
from addon.common.net import Net
import xbmc, sys
xbmc.log(repr(sys.argv))




USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.program.kryptonupdatermalee'
ADDON = xbmcaddon.Addon(id=addon_id)
addon= xbmcaddon.Addon()
path = addon.getAddonInfo('path').decode("utf-8") + "/icon.png"
ADDON = xbmcaddon.Addon(id=addon_id)
AddonID='plugin.program.kryptonupdatermalee'
AddonTitle="Krypton  Updater"
dialog       =  xbmcgui.Dialog()
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/')) 
VERSION = "0.0.1"
DP = xbmcgui.DialogProgress()
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Krypton  Updater"            
BASEURL = "https://archive.org/download/kodisystem/"
BASEURL1 = "https://archive.org/download/LeKryptonUpdates/"
BASEURL3 = "https://archive.org/download/LeKryptonUpdates/"
BASEURL4 = "https://archive.org/download/LeKryptonUpdates/"
H = 'http://'
EXCLUDES     = ['weather.yahoo','plugin.video.exodus','plugin.video.nfl.gamepass','plugin.video.ntv','plugin.video.youtube','inputstream.rtmp','service.libreelec.settings','skin.confluence','script.module.addon.common','repository.maleemedia','plugin.program.kryptonupdatermalee','plugin.program.buildrestore','plugin.program.lefirmwareupdate']

def INDEX():
	#addDir('INDEX',BASEURL,1,ART+'info.png',FANART,'')
	addDir('CLICK TO UPDATE',BASEURL,22,ART+'update.png',FANART,'')
	addDir('MAINTENANCE',BASEURL,9,ART+'maintenance.png',FANART,'')
	#addDir('FRESH BUILD',BASEURL4+'/libreelec.zip',27,ART+'freshbuild.png',FANART,'')
	#addDir('GUI FIX',BASEURL3+'/libreelecgui.zip',24,ART+'guifix.png',FANART,'')
	setView('movies', 'MAIN')


def MAINTENANCE():
    #addDir('MAINTENANCE',BASEURL,9,ART+'maintenance1.png',FANART,'')
    #addDir('CLEAR CACHE','url',4,ART+'clearcache.png',FANART,'')
    addDir('FRESH BUILD',BASEURL4+'/libreelec.zip',27,ART+'freshbuild.png',FANART,'')
    #addDir('GUI FIX',BASEURL3+'/libreelecgui.zip',24,ART+'guifix.png',FANART,'')
    addDir('ENABLE ADDONS',BASEURL,26,ART+'enableaddons.png',FANART,'')
    addDir('WIPE ALL','url',6,ART+'freshstart.png',FANART,'')
    setView('movies', 'MAIN')	

	
def MXQUPDATE():
	addDir('UPDATE BUILD',BASEURL1+'/libreelecupdate.zip',5,ART+'updatebuild.png',FANART,'')
	setView('movies', 'MAIN')


#######################################UPDATE BUILD 5 ##############################

def WIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.confluence"}}')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin( 'ActivateWindow(Home)' )
    dp = xbmcgui.DialogProgress()
    dp = xbmcgui.DialogProgress()
    dp.create("Krypton  Updater","DOWNLOADING THE UPDATE ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(5)
    dp.update(0,"", "INSTALLING THE UPDATE")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    time.sleep(2)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
	#time.sleep(5)
	#xbmc.executebuiltin('Action(Right)')
	#time.sleep(2)
	#xbmc.executebuiltin('Action(Select)')
	#time.sleep(1)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.sleep(1000)
    xbmc.executebuiltin('Action(Select)')
    enableaddons()

	#################################GUI FIX 24 ###########################
def WIZARD2(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("Krypton  Updater","DOWNLOADING THE GUI FIX ",'', 'PLEASE WAIT.........')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "INSTALLING THE GUI FIX")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("Krypton  Updater", "TO SAVE CHANGES YOU NEED TO PULL THE POWER. AFTER CLICKING OK PULL THE PLUG AND REBOOT")
    killxbmc()

	#################################FRESH BUILD 27 ###########################
def WIZARD3(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.confluence"}}')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin( 'ActivateWindow(Home)' )
    dp = xbmcgui.DialogProgress()
    dp.create("Krypton  Updater","DOWNLOADING THE FILES ",'', 'PLEASE WAIT.....')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "INSTALLING THE FRESH BUILD")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    time.sleep(2)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.skin","value":"skin.estuary"}}')
	#time.sleep(5)
	#xbmc.executebuiltin('Action(Right)')
	#time.sleep(2)
	#xbmc.executebuiltin('Action(Select)')
	#time.sleep(1)
    xbmc.executebuiltin('SendClick(11)')
    xbmc.sleep(500)
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.sleep(1000)
    xbmc.executebuiltin('Action(Select)')
    enableaddonsfresh()	
	
def BUILDRESTORE():
	xbmc.executebuiltin( 'RunAddon(plugin.program.lebuildrestore)' )
	#xbmc.executebuiltin('ActivateWindow(Home)')
	
	#################################
####ENABLE ADDONS KRYPTON########
#################################
	
#Makes log easier to follow:
def printstar():
	print "[COLOR white]***************************************************************************************"
	print "[COLOR white]***************************************************************************************"

	
def enableaddons():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin(' Notification(UPDATE IS FINISHED,Enjoy the new fixes and tweaks,6000, %s)' % (path))
	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmcgui.Dialog().ok('Some addons were not enabled.', 'Check your log for details.')
	xbmc.sleep(200)
	#FOR UNIVERSAL BUILD NO REBOOT
	#xbmc.executebuiltin('ActivateWindow(Home)')
	#FOR LibreELEC AND EmbER BUILDS REBOOT COMMAND
	xbmc.executebuiltin('Reboot')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
	
def enableaddonsfresh():
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin(' Notification(FRESH BUILD DONE,Kodi will now reboot,6000, %s)' % (path))
	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1
	# If any failures put a message on the screen.
	ERROR = len(FAIL)
	if ERROR > 0:
		xbmcgui.Dialog().ok('Some addons were not enabled.', 'Check your log for details.')
	xbmc.sleep(200)
	#FOR UNIVERSAL BUILD NO REBOOT
	#xbmc.executebuiltin('ActivateWindow(Home)')
	#FOR LibreELEC AND EmbER BUILDS REBOOT COMMAND
	xbmc.executebuiltin('Reboot')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()	

def ENABLEBUTTON():
   enableaddonsbutton()
   #enableaddons()
   
def enableaddonsbutton():
	dialog = xbmcgui.Dialog()
	dialog.ok("Krypton  Updater", "ADDONS WILL NOW BE ENABLED.")
	PATH = os.path.join(xbmc.translatePath('special://home/'), "addons")
	# Make some lists:
	ADDONS = []
	SUCCESS = []
	FAIL = []

	# Move stuff in or out of addons folder and then:
	xbmc.executebuiltin( 'UpdateLocalAddons' )
	xbmc.executebuiltin("UpdateAddonRepos")

	# Exclude addons I don't want to check (pvr is usually off on my system, metadata is the kodi repo stuff, packages folder obviously)
	for i in os.listdir(PATH):
		if os.path.isdir(os.path.join(PATH,i)) and 'packages' not in i and 'pvr' not in i and 'temp' not in i and 'metadata' not in i:
			ADDONS.append(i)
	printstar()
	print ADDONS
	n = len(ADDONS)
	print ("There are %d addons in the kodi addons folder that will be checked." % n)
	printstar()
	# Check each addon - if not enabled try enable, then check status again.  Report success or fail.
	if n > 0:
		c = 0
		d = 0
		e = 0
		while c < n:
			CHECK = ADDONS[c]
			print ("Now checking %s ." % CHECK)
			if not xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % CHECK)
				xbmc.sleep(200)
				if xbmc.getCondVisibility('System.HasAddon(%s)' % CHECK):
					d = d + 1
					SUCCESS.append(CHECK)
				else:
					# is addonid same as foldername?  If not get id from addon.xml and try again!
					ADDONXML = os.path.join(PATH, CHECK, "addon.xml")
					# get the addonid
					with open(ADDONXML) as f:
						for line in f:
							if "<addon id=" in line:
								start = "<addon id=\""
	#                            end = "\" name="
								end = "\""
								ADDONID = (line.split(start))[1].split(end)[0]
								print ('Folder is %s' % CHECK)
								print ('Addonid to enable is %s' % ADDONID)
								if not xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
									xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "%s","enabled":true}}' % ADDONID)            
									xbmc.sleep(200)
									if xbmc.getCondVisibility('System.HasAddon(%s)' % ADDONID):
										d = d + 1
										SUCCESS.append(CHECK)
									else:
										e = e + 1
										FAIL.append(CHECK)
					
			c = c + 1

			
			# Put results up on the screen:
		line1 = ('%d addons enabled'% d)
		line2 = ('%d addons not enabled'% e)
		line3 = 'Check the log for details.'
		
	if d > 0 and e > 0:
		xbmcgui.Dialog().ok(line1, line2, line3)
	elif e > 0:
		xbmcgui.Dialog().ok(line2, line3)
	elif d > 0:
		xbmcgui.Dialog().ok(line1, line3)
	elif d == 0 and e == 0:
		line3 = 'No action taken.'
		xbmcgui.Dialog().ok(line1, line3)
	else:
		line1 = 'Something funny going on.'
		xbmcgui.Dialog().ok(line1, line3)
	xbmc.sleep(200)
	xbmc.executebuiltin('ActivateWindow(Home)')
	
	# print results to log
	printstar()
	print ("[COLOR red]%s addons were checked" % n)
	print ("[COLOR red]%s addons were enabled" % d)
	print ("[COLOR red]There were %s failures" % e)
	print ("[COLOR red]Enabled addons: %s" % SUCCESS)
	print ("[COLOR red]Failures: %s" % FAIL)
	printstar()
	exit()
		
	
################################
###DELETE PACKAGES##############
####THANKS GUYS @ XUNITY########

def DeletePackages(url):
    print '############################################################       DELETING PACKAGES             ###############################################################'
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Krypton  Updater", "Packages successfully Removed", "[COLOR steelblue]Brought To You By MR ED REPO[/COLOR]")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("Krypton  Updater", "Sorry we were not able to remove Package Files", "[COLOR steelblue]Brought To You By MR ED REPO[/COLOR]")
    


#################################
###DELETE CACHE##################
####THANKS GUYS @ XUNITY########
	
def deletecachefiles(url):
    print '############################################################       DELETING STANDARD CACHE             ###############################################################'
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete TEMP dir Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				

    dialog = xbmcgui.Dialog()
    dialog.ok("Krypton  Updater", " All Cache Files Removed", "[COLOR steelblue]Brought To You By MR ED REPO[/COLOR]")
 
        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
###############################################################
###FORCE CLOSE KODI - ANDROID ONLY WORKS IF ROOTED#############
#######LEE @ COMMUNITY BUILDS##################################

def killxbmc():
    choice = xbmcgui.Dialog().yesno('Now Force Close Kodi', 'PULL THE POWER PLUG FROM THE BACK AND REBOOT', nolabel='DONT CLICK ME',yeslabel='DONT CLICK ME')
    if choice == 0:
        return
    elif choice == 1:
        return
##########################
###DETERMINE PLATFORM#####
##########################
        
def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'
    
############################
###FRESH START##############
####THANKS TO TVADDONS######

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def FRESHSTART(params):
    plugintools.log("freshstart.main_list "+repr(params)); yes_pressed=plugintools.message_yes_no(AddonTitle,"[COLOR red][B]!!!WARNING!!![/B][/COLOR] ONLY CLICK YES IF YOU WANT DO DELETE ALL SETTINGS. EXODUS, YOUTUBE, TRAKT, NTV & NFL GAMEPASS SETTINGS WILL STAY")
    if yes_pressed:
        addonPath=xbmcaddon.Addon(id=AddonID).getAddonInfo('path'); addonPath=xbmc.translatePath(addonPath);
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        total_files = sum([len(files) for r, d, files in os.walk(xbmcPath)]); del_file = 0;
        DP.create(AddonTitle,"Clearing all files and folders:",'', '')
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=True):
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in files:
                    del_file += 1
                    DP.update(int(percentage(del_file, total_files)), '', 'File: [color=#000000]%s[/color]' % name, '')
					#ADD ANY FILES YOU DONT WANT DELETED HERE
                    if name in ['guisettings.xml', 'Addons27.db', 'kodi.log']: plugintools.log("Keep Log File: %s" % name)
                    else:
                        try: os.remove(os.path.join(root,name))
                        except:
                            if name not in ["Addons27.db","MyVideos99.db","Textures13.db","MyVideos107.db"]: failed=True
                            plugintools.log("Error removing "+root+" "+name)
                       
            for root, dirs, files in os.walk(xbmcPath,topdown=True):           
                dirs[:] = [d for d in dirs if d not in EXCLUDES]
                for name in dirs:
                    DP.update(100, '', 'Cleaning Up Empty Folder: [color=#000000]%s[/color]' % name, '')
                    if name not in ["Database","userdata","temp","addons","addon_data"]:
                        shutil.rmtree(os.path.join(root,name),ignore_errors=True, onerror=None)

            DP.close()
            if not failed: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot re-launch [COLOR lime][B]Krypton Updater[/B][/COLOR] FRESH BUILD,16500, %s)' % (path))
            else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,After reboot click re-launch [COLOR lime][B]Krypton Updater[/B][/COLOR] FRESH BUILD,16500, %s)' % (path))
        except: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    else: xbmc.executebuiltin('Notification(STANDBY KODI WILL NOW REBOOT,Your settings have NOT been changed,16500, %s)' % (path))
    xbmc.sleep(16500)	
    xbmc.executebuiltin('Reboot')
    #xbmc.executebuiltin('ActivateWindow(Home)')
       
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==2:
        BUILDMENU()

elif mode==3:
        SYSTEM()
		
elif mode==4:
        deletecachefiles(url)
		
elif mode==5:
        WIZARD(name,url,description)

elif mode==6:        
	FRESHSTART(params)
	
elif mode==7:
       DeletePackages(url)

elif mode==8:
       INFO()
       
elif mode==9:
       MAINTENANCE()
	   
elif mode==22:
       MXQUPDATE()
	
elif mode==24:
        WIZARD2(name,url,description)	
	   
elif mode==26:
       ENABLEBUTTON()

elif mode==27:
       WIZARD3(name,url,description)	  
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
